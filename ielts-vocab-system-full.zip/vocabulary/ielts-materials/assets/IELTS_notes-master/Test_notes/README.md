# Hit lists of mocks

![band](./band.png)

# Test result

![band](./test.png)
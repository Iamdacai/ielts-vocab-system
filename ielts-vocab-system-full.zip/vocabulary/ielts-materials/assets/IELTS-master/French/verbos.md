| Idioma Extranjero <br /> verbes | Pronunciacion <br /> vejrbes | Idioma Natal <br /> Verbos | Asociación |
|:-----------------:|:-------------:|:------------:|------------|
| être              | etjre         | Ser / Estar  | __SER__ _*E3*_ |
| avoir             | avuajr        | Tener / Haber | __tener__ un _*jaguar*_          |
| il y a            | ilia          | Hay          | __hay__ un ilia kuriaki and the valderramas |
| vouloir           | vuluarj       | Querer       | las aves van a __querer__ _*volar*_ |
| desirer           | desire        | Desear       | Bod Dylan __desea__ a _*Desire*_ (17mo album)|
| aimer             | emejr         | Amar / Gustar | __GUSTAV GUSTAV__ Y __AMANDA__ aman a "M" (James Bond) |
| aider             | edejr         | Ayudar       | __AYUDA__ a _*Eddert*_ |
| tenter            | t(ea)ntejr    | Intentar     | __INTENTAR__ como una _*tonta*_ la _*tia*_ |
| parvenir          | pajrvenijr    | Conseguir    | __CONSEGUIR__ una _*parbula*_ |
| demander          | demandejr     | Pedir        | __PEDIR__ que _*demanden*_ a los _*demas*_ |
| nécessiter        | necesitejr    | Necesitar    | __NECESITAR__ un _*neceser*_ para _*nelson*_ |
| habiter           | habite        | Vivir        | El hobbit __VIVIR__ en su _*habitat*_ natural |
| naître            | netjre        | Nacer        | No se puede __NACER__  _*Nebraska*_  |
| grandir           | gjrandijr     | Crecer       | Van a __CRECER__ las _*Granadinas*_ muy _*Grandes*_ |
| mourir            | mujrijr       | Morir        | Se va a __MORIR__ _*Mou*_rihno si seguimos jugando así |
| sentir            | sentijr       | Sentir       | -- |
| fait mal          | fet mal       | Doler        | __doler__ que explote un _*FET*_ Field-Effect Transistor |
		
		


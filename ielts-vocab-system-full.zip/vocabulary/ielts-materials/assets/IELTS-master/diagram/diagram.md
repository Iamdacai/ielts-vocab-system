##Esquema de envio

<kbd>  es DTE?  </kbd> &rarr;&rarr; <kbd>  dte_carg_dte  </kbd> &rarr;&rarr; <kbd>  DTE_ENCA_DOCU </kbd>
&uarr;  
<kbd>  dbq_scan_arch  </kbd>  
&uarr;  
<kbd>DBQ_ARCH_CLOB</kbd> <kbd>DBQ_ARCH</kbd>  
      &uarr;    &uarr;  
<kbd> dbq_regi_arch </kbd>  
       &uarr;  
<kbd>  txt  </kbd>  

[//]: # &larr;, &uarr;, &rarr; and &darr;
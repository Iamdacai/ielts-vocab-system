1. It/something appeals to me because instead of i like it because 

2. I get a lot of pleasure out of doing something instead of i like to do something 

3. I am keen to do something

4. I am keen on doing something

5. I am not keen on doing something

6. I am a keen something 

7. I am fond of something

8. I am fond of doing something

9. To grow fond of something/ I've grown fond of something 



Ask for clarification 

10. Sorry, I didnt quite catch that

11. Could you say that again?

12. Could you what you mean by something?



Provide clarification 

13. To put it another way

14. What I am trying to say is

15. What I mean is 



If you are not sure what to say 

16. That's a difficult question

17. That's a good question 

18. I never thought about it before but I guess



Agreeing with something

19. I couldn't agree more

20. I totally agree

21. Absolutely 

22. Definitely 

23. Precisely 

24. I tend to agree with that

25. I tent to agree that 

26. it depends

27. I think it really depends



Disagreeing with something

28. That's one way of looking at it/however

29. That's not always true



Expressing your opinion not the fact

30. As far as I am concerned

31. As I see it

32. As far as I know 

33. I suppose

34. I would imagine



Expressing facts 

35. I'm convinced

36. There's no other way 



Conclude

37. To wrap up/sum up
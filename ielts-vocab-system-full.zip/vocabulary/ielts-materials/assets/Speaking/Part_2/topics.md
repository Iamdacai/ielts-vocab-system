### **ielts-yasi.englishlab.net**

Updated Oct 24  2019

 

**IELTS Speaking Test**

**Index of Part 2 & Part 3 Topics and Questions**  

**Page 19**

**This page shows the Part 2 Topics for September - December, 2019.**

 

**Note:** Some of the September topics and the Part 3 questions might be changed a bit during the months of October, November & December.

**********************************************************



**Page 18****8**

**946****.  A Change of Plan**  (Jan 2019)  **(Probably no longer used)**

**947.  A Person with Interesting Ideas**  (May 2019)

**948.  A Band or Singer**  (May 2019)

**949.  Incorrect Information**  (May 2019)

**950****.  A Place Near Water** (May 2019)

 

**Page 18****9**

**951****.  A Phone Call**  (May 2019)

**952.  A Game Show** **or Quiz Program**  (May 2019)

**953.  A Famous Foreign Person**  (May 2019)

**954.  An Invitation to Dinner**  (May 2019)

**955****.  A Friend who Encouraged You**  (May 2019)

 

**Page 1****90**

**956****.  An Historical Building**  (May 2019)

**957.  A Prize You Would Like to Win**  (May 2019)

**958.  Someone who is Good at Languages**  (May 2019)

**959.  A Time You Got Up Early**  (May 2019)

**960****.  You Used the Internet to Solve a Problem**  (May 2019)

 

**Page 1****91**

**961****.  Someone Who Helps Others**  (May 2019)

**962.  A Child Who Made You Laugh**  (May 2019)

**963.  Something Special You Took Home**  (May 2019)

**964.  An Advertisement You Remember Well**  (May 2019)

**965****.**  **Advice About Work or Study**  (May 2019)

 

**Page 1****92**

**966****.**  **A Sport that You Do**  (May 2019)

**967.  A Practical Skill**  (May 2019)

**968.  A Vehicle Breakdown**  (May 2019)

**969.  A Time You Stayed with Your Friends (or a friend)**  (May 2019)  

**970****.**  **A Park or Garden**  (May 2019) 

 

**Page 1****93**

**971****.  A Childhood Toy**  (Sep 2019) 

**972.**  **A Person Who** **Usually Travels by Plane**  (Sep 2019) 

**973.  Meeting Someone For the First Time**  (Sep 2019) 

**974.  Someone Good at Their Job**  (Sep 2019) 

**975****.  An Unusual Holiday**  (Sep 2019) 

 

**Page 1**[**9****4**](http://ielts-yasi.englishlab.net/PARTS_2_and_3_P194.htm)

**976****.  A Time When You Were Bored**  (Sep 2019) 

**977.  A Film You Would Like to Share**  (Sep 2019) 

**978.  A Place With Good Memories**  (Sep 2019) 

**979.  A Place to Read and Write**  (Sep 2019) 

**980****.**  **A Colourful Place**  (Sep 2019) 

 

**Page 1****95**

**981****.**  **A Fashion Item You Enjoy Wearing**  (Sep 2019 or May 2019)

**982.**  **Something You Borrowed**  (Sep 2019)

**983.  An Indoor Game**  (Sep 2019)  **Possibly not a current Part 2 topic**

**984.  A Conversation With a Stranger**  (Sep 2019)

**985****.  A Product From Your Country** (Sep 2019)

 

**Page 1****96**

**986****.  An Achievement You Celebrated**  (Sep 2019)

**987.  A School** **You Attended**  (Sep 2019)

**988.  A Gift That Took a Long Time to Choose**  (Sep 2019)

**989.  A Picture or Photograph at Home**  (Sep 2019)

**990****.**  **A Beautiful Sky**  (Sep 2019)

 

**Page 1****97**

**991****.**  **A Special Day**  (Sep 2019)

**992.  Tired but Had to Stay Awake**  (Sep 2019)

**993.**  **A Time You Lost Something**  (Sep 2019)

**994.**  **A Place You Visited With Friends**  (Sep 2019)

**995****.**  **A TV Program You Enjoyed**  (Sep 2019)

 

**Page 1****98**





**996.  A New Building**  (Sep 2019)

 

**********************************************************
What are the advantages, and the disadvantages, of making a plan?

## Word list

procrastination


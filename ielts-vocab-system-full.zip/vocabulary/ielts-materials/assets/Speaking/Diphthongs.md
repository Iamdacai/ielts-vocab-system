# Diphthongs 

## /ɪə/

near /nɪə/

hear /hɪə/

weary /ˈwɪəri/

## /ʊə/

tour /tʊə/

pure /pjʊə/

cure /kjʊə/

## /aɪ/

price /praɪs/

high /haɪ/

try /traɪ/

## /ɔɪ/

choice /tʃɔɪs/

noise /nɔɪz/

boy /bɔɪ/

## /əʊ/

boat /bəʊt/

show /ʃəʊ/

know /nəʊ/

/ɔː/

coat /kəʊt/	caught /kɔːt/

dough /dəʊ/	door /dɔː/

sew /səʊ/	saw /sɔː/

flow /fləʊ/	floor /flɔː/

## /eə/

square /skweə/

fair /feə/

pair /peə/

/æ/

dared /deəd/	dad /dæd/

glared /ɡleəd/	glad /glæd/

Mary /ˈmeəri/	marry /ˈmæri/

## /aʊ/

mouth /maʊθ/

now /naʊ/

fowl /faʊl/

/əʊ/

couch /kaʊtʃ/	coach /kəʊtʃ/

clown /klaʊn/	clone /kləʊn/

loud /laʊd/	load /ləʊd/

found /faʊnd/	phoned /fəʊnd/

## /eɪ/

face /feɪs/

day /deɪ/

break /breɪk/

/iː/

ate /eɪt/	eat /iːt/

faced /feɪst/	feast /fiːst/

great /greɪt/	greet /griːt/

mate /meɪt/	meet /miːt/
## 3 parts of the test

11 to 14 minutes overall, timing is very strict

- Part 1: 4 to 5 minutes
- Part2: 3 to 4 minutes
- Part3: 4 to 5 minutes

## Scoring system

4 scores, 25% each

1. Fluency and coherence
2. Vocabulary
3. Grammar
4. Pronunciation (clearly)

## Advice

- be ready
- know what to expect
- know what the examiner expects from you
- natural language, not difficult language
- answer as quickly as you can

Don't worry about:

- body language
- eye contact
- the quality of your ideas
- whether the examiner agrees with you
- presentation skills

## Amis

- give you a method
- prepare topics and common questions


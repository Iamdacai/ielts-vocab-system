# describe an activity (part2)

what, where, who, why?

- a hobby
- a sport
- a game
- something healthy that you do
- something new that you have done recently

**a healthy sport (swimming)**

- keep fit, stay in good condition
- get in better shape
- feel refreshed
- rejuvenated, invigorated
- gives me an energy boost
- a good cardiovascular workout
- build strength and endurance
- a low-impact sport
- helps to relieve stress
- relaxing, helps to clear my mind

an enjoyable game (chess)

- board game, a chess set
- pieces e.g. king, queen, bishop
- taking the opponent's pieces
- checkmate
- hone my skills
- thinking ahead
- out-think / outwit the opponent
- concentration, mental workout
- problem solving, strategy
- learn from mistakes / losses

> Swimming is relaxing:
>
> Yesterday I had a lot on my mind, but as soon as I hit the water, all of my troubles disappeared.
>
> I learned from my losses:
>
> I had one friend who always beat me, but I copied his strategies when playing other people.

# Example

> Describe something healthy you enjoy doing

You should say

- what you do
- where you do it
- who you do it with
- and explain why you think doing this is healthy


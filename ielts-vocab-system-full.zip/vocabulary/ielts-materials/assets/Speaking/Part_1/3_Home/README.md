# **Hometown** and Home

Many of the questions have the words, "(Why?/Why not?)" written in the examiner's question book after the question. I have not often shown that here but you should include this information when you answer any questions about your preferences, opinions, likes and dislikes or any other answer that obviously needs you to state a **reason** for a complete, coherent answer. If you do not, the examiner will ask you (***= must*** ask you) "Why?" or, "Why not?" If the examiner is forced to ask that several times, you will be losing valuable time and you will not give a good impression.


# Vocabulary List

Every list includes 50 words which are saved from all sources (Podcasts, Books, magazines and tests).

## Style

No. Word

- Brief explanation

- Full Definitions

  Synonyms

- Collections

- Examples

## Sources

- [Vocabulary.com](https://www.vocabulary.com/)
- [LDOCE5](https://www.ldoceonline.com/)
- [Colins](https://www.collinsdictionary.com/)
- [英语常用词疑难用法手册](https://book.douban.com/subject/5038844/)

## Software

- [GoldenDict](http://goldendict.org/)
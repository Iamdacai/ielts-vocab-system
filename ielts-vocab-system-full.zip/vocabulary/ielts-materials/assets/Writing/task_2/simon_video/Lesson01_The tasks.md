# A IELTS training course

1. Understanding the task

   Write an essay

   -- Minimum 250 words

   -- 40 minutes

   -- Universal topics

   -- 4 question types

   -- Four scoring criteria

      - Task response

      - Coherence and cohesion

      - Vocabulary

      - Grammar

     

2. **Break the task into parts**

   4 paragraphs, about 13 sentences

   Planning: 10 minutes

   - Introduction
     - 2 sentences
     - 5 minutes
   - two main paragraphs
     - 5 sentences each
     - 20 minutes
   - Conclusion
     - 1 sentence
     - 5 minutes

3. Methods, techniques

4. Lots of practice

5. Feedback, measure progress
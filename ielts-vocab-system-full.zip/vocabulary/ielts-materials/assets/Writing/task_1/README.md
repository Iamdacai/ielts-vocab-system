# Phrases

## Introduction

the line graph, the (three) (bar) chart(s)

the first (bar) chart shows (changes in ....), and the second chart shows that figure(s) for ...

show, compare, give information about

## Overview

It is clear that ....... (, and that), Overall

on/over the period shown, in comparison with

## Details

### Description

the figure(s) for, the rate of, the number of

Figures are given for xxxx(year)

We can also see that

### Comparison

compared to, By/In contrast

... is/are about ..... (and ... respectively)

#### Increase

... is (considerable) higher (in ...) than (in ...)

rise (dramatically/significantly) (from ...) to (a peak of) ...

... see a small/rapid rise/growth

By xxxx(year), ... had increased to

doubled to

#### Decrease

fell suddenly, fell back to, fell from (about) ... to ...

there was a fall in

(the figure) drop to

#### Remain/ Reach

remain at/below this/similar level, remain stable

stand at/around

fluctuate

reach approximately

### Others

... account for the largest proportion of ...

this could be explained by the fact that

As a result

At the same time

## How to build sentence

1. Basic fact (subject + verb)

   > The number of Japanese tourist who travelled abroad increased.

2. Number

3. When?

4. Exactly this number?

5. Add an verb

6. Rephrase with a noun

7. Can we begin with a noun?

   > There was a dramatic increase in the number of Japanese tourists who travelled abroad from just under 5 million to around 15 million between 1985 and 1995, a rise of about 10 million in 10 years.
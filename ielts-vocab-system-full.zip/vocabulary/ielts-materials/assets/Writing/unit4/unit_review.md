#Unit Review

###what to bring to the test day:
* proof of identity (should have a signature, your date of birth an a photograph)
* Depending on where you take your test, your passport is often required
* Pencil and/or pens
* pencil sharpener
* erasers
* water (in a clear bottle with label removed)
* tissues

###What **not** to take into the test room:
* mobile phone and other electronics devices
* food
* bags
* all other belongings

###Other informations
 * Check the website of the test center
 * Ask a supervisor